import mysql from 'mysql';

// Create a connection to the MySQL database
const connection = mysql.createConnection({
  host: 'database-1.cwzjhkgs6o1v.us-west-1.rds.amazonaws.com',
  user: 'klee',
  password: 'dlfrlTmsmsskfdldi',
  database: 'journalDB'
});

exports.handler = async (event, context) => {
  const { prompt, entry } = JSON.parse(event.body);

  // Insert the journal entry into the database
  const sql = 'INSERT INTO entries (prompt, entry) VALUES (?, ?)';
  const params = [prompt, entry];
  connection.query(sql, params, (error, results) => {
    if (error) {
      console.error(error);
      return {const AWS = require('aws-sdk');
const dynamoDB = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    let response = {};
    
    try {
        const userData = JSON.parse(event.body);
        
        const params = {
            TableName: "Users", // Make sure this is the name of your DynamoDB table
            Item: {
                email: userData.email,
                firstName: userData.firstName,
                lastName: userData.lastName,
                dateOfBirth: userData.dateOfBirth,
                address: userData.address,
                phoneNumber: userData.phoneNumber
            }
        };

        await dynamoDB.put(params).promise();

        response = {
            statusCode: 200,
            body: JSON.stringify({ success: true })
        };
    } catch (error) {
        response = {
            statusCode: 500,
            body: JSON.stringify({ success: false, error: error.message })
        };
    }
    
    return response;
};

        statusCode: 500,
        body: JSON.stringify({ message: 'Internal server error' })
      };
    } else {
      return {
        statusCode: 200,
        body: JSON.stringify({ message: 'Journal entry saved successfully' })
      };
    }
  });
};
